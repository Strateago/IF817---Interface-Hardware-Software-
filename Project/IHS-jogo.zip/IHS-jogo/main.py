import pygame
from pygame.locals import *
from sys import exit
import random

pygame.init()

score = 0
width = 640
height = 480
X_sugar = random.randint(240, 600)
Y_sugar = 40
X_mug = 200
Y_splash = 218
MOVE_MUG = True
END_GAME = False
BLACK = (0, 0, 0)
Speed_mug = 25


Font1 = pygame.font.SysFont('franklingothicmedium', 25, True, False)
Font2 = pygame.font.SysFont('franklingothicmedium', 25, False, True)
Font3 = pygame.font.SysFont('franklingothicmedium', 50, False, True)
screen = pygame.display.set_mode((width, height))
sugar = pygame.image.load('sugar.png')
sugar = pygame.transform.scale(sugar, (40, 40))
background = pygame.image.load('background.png').convert()
background = pygame.transform.scale(background, (640, 480))
mug = pygame.image.load('mug.png')
mug = pygame.transform.scale(mug, (75, 75))


class Splash(pygame.sprite.Sprite):

    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.sprites = []
        self.sprites.append(pygame.image.load('Splash0.png'))
        self.sprites.append(pygame.image.load('Splash1.png'))
        self.sprites.append(pygame.image.load('Splash2.png'))
        self.sprites.append(pygame.image.load('Splash3.png'))
        self.sprites.append(pygame.image.load('Splash4.png'))
        self.atual = 0
        self.image = self.sprites[self.atual]
        self.rect = self.image.get_rect()

        self.animate = False

    def splash(self):
        self.animate = True

    def update(self, X_mug):
        self.rect.topleft = X_mug, Y_splash
        if self.animate == True:
            if self.atual == 0:
                self.atual = self.atual + 1
            else:
                self.atual += 0.5
            if self.atual >= len(self.sprites):
                self.atual = 0
                self.animate = False
            self.image = self.sprites[int(self.atual)]

Game_Sprites = pygame.sprite.Group()
Splash_ = Splash()
Game_Sprites.add(Splash_)
clock = pygame.time.Clock()

while True:
    clock.tick(30)
    screen.fill(BLACK)
    msg1 = 'Press space for stop the mug'
    Score = f'SCORE : {score}/8'
    #msg2 = 'Enjoy your coffee '
    text1 = Font2.render(msg1, True, (250, 250, 250))
    text2 = Font1.render(Score, True, (250, 250, 250))
    #text3 = Font3.render(msg2, True, (250, 250, 250))
    screen.blit(background, (0, 0))
    screen.blit(sugar, (X_sugar, Y_sugar))
    screen.blit(mug, (X_mug, 260))

    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            exit()
        if pygame.key.get_pressed()[K_LEFT]:
            X_mug = X_mug - Speed_mug
            if X_mug <= 200:
                X_mug = width

        if pygame.key.get_pressed()[K_RIGHT]:
            X_mug = X_mug + Speed_mug
            if X_mug >= width:
                X_mug = 200

    if END_GAME == False:
        Y_sugar = Y_sugar + 5
        if Y_sugar >= 280:
            Y_sugar = 40
            X_sugar = random.randint(240, 600)

    if score >= 8:
        END_GAME = True
        #screen.blit(text3, (200, 200))

    if X_mug - 10 <= X_sugar <= X_mug + 20 and 250 <= Y_sugar <= 280:
        score = score + 1
        Splash_.splash()
        Game_Sprites.draw(screen)
        Game_Sprites.update(X_mug)
        Y_sugar = 40
        X_sugar = random.randint(240, 600)

    screen.blit(text1, (5, 440))
    screen.blit(text2, (520, 30))
    Game_Sprites.draw(screen)
    Game_Sprites.update(X_mug)
    pygame.display.flip()





